package com.example.apitest;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;


public class ItemsAdapter extends RecyclerView.Adapter<ItemsAdapter.ViewHolder> {
    private Context context;
    private List<Apparel> list;

    public ItemsAdapter(Context context,List<Apparel> list) {
        this.context = context;
        this.list=list;
    }

    @NonNull
    @Override
    public ItemsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemsAdapter.ViewHolder holder, int position) {
        holder.title.setText(list.get(position).getName());
        Glide.with(context).load(list.get(position).getImage()).into(holder.icon);
        holder.price.setText(list.get(position).getPrice());
        holder.rating.setText(list.get(position).getRating());



    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView title,price,rating;
        public ImageView icon;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            title = itemView.findViewById(R.id.title);
            icon=itemView.findViewById(R.id.icon);
            price=itemView.findViewById(R.id.price);
            rating=itemView.findViewById(R.id.rating);
        }
        @Override
        public void onClick(View view){
            Log.d("card","clicked");

        }


    }
}


