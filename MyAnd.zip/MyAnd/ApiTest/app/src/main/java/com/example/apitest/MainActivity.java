package com.example.apitest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.graphics.drawable.Drawable;
import android.icu.text.IDNA;
import android.os.Bundle;

import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.ViewTarget;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    public static ArrayList itemInfoList = new ArrayList<>();
    Apparel apparel;
    ItemsAdapter  itemsAdapter;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));
//
//        final TextView textView = (TextView) findViewById(R.id.textView);
//        final ImageView imageView = (ImageView) findViewById(R.id.imageView);
        // Instantiate the RequestQueue.

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonArrayRequest JsonArrayrequest = new JsonArrayRequest(Request.Method.GET, "https://fakestoreapi.com/products", null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response ) {




                try {


                    JSONArray jsonarra = response;
                    for (int i = 0; i < jsonarra.length(); i++) {
                        JSONObject jsonobject = jsonarra.getJSONObject(i);
                        String name = jsonobject.getString("title");
                        String img=jsonobject.getString("image");
                        String price=jsonobject.getString("price");
                        JSONObject ratingObject=jsonobject.getJSONObject("rating");
                        String rating=ratingObject.getString("rate");

                        apparel = new Apparel(name,img,price,rating);
                        
                        itemInfoList.add(apparel);


//                                Glide.with(MainActivity.this).load(img).into(imageView);
                    }
                    itemsAdapter=new ItemsAdapter(MainActivity.this,itemInfoList);
                    recyclerView.setAdapter(itemsAdapter);





                    Log.d("myapp", "Success");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("myapp","something went wrong"+error);

            }
        });
        JsonArrayrequest.setRetryPolicy(new DefaultRetryPolicy( 50000, 5, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));



// Add the request to the RequestQueue.
        queue.add(JsonArrayrequest);
    }
    
    
       

}