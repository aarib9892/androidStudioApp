package com.example.apitest;


public class Apparel {
    public String name;
    public String img;
    public String price;
    public String rating;


    public Apparel(String name,  String img, String price, String rating) {


        this.name=name;
        this.img=img;
        this.price=price;
        this.rating=rating;
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name=name;
    }



    public String getImage() {
        return img;
    }

    public void setImage(String img) {
        this.img=img;
    }


    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price=price;
    }


    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating=rating;
    }



};

